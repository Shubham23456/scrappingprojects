import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class YelpCrawlSpider(CrawlSpider):
    name = 'info'

    start_urls = ['https://www.zillow.com/agent-finder/real-estate-agent-reviews/%20for%20example:%2010001']






    le_yelp_details = LinkExtractor(restrict_xpaths='//h3//a')
    le_next = LinkExtractor(restrict_xpaths='//li[@class="zsg-pagination-next"]')

    rule_yelp_details = Rule(le_yelp_details, callback='parse_item', follow=True)
    rules = (
        rule_yelp_details,
    )

    rule_next = Rule(le_next, follow=True)
    rules = (
        rule_yelp_details,
        rule_next
    )

    def parse_item(self, response):
        yield {
            #'Agent-URL': response.xpath('..//@href').get(),
            'Agent-Name': response.xpath('//h1[@class="Text-c11n-8-39-0__aiai24-0 StyledHeading-c11n-8-39-0__ktujwe-0 gDqTKI"]/text()').get(),
            'company-name': response.xpath('//div[@class="Text-c11n-8-39-0__aiai24-0 hWdvTH"][1]/text()').get(),
            # 'Foodtype': response.xpath(
            #     '//*[@id="wrap"]/div[2]/yelp-react-root/div[1]/div[3]/div[1]/div[1]/div/div/span[3]/span/a/text()').get(),
            'Agent-Phone number': response.xpath('//*[@id="__next"]/div/div[3]/aside/div[2]/div/dl/div[2]/dd/span/text()').get(),
            'Agent-Address': response.xpath('//*[@id="__next"]/div/div[3]/aside/div[2]/div/dl/div[1]/dd/span/text()').get(),
            # 'images': response.xpath('//img[@class=" photo-header-media-image__373c0__rKqBU"]/@src').get(),
            # 'rating': response.xpath(
            #     '//span[@class=" display--inline__373c0__31SCF margin-l0-5__373c0__1Ju8t border-color--default__373c0__r305k"][1]/text()').get(),
            # 'Locationhours': response.xpath(
            #     '// span[@class=" display--inline__373c0__31SCF margin-l1__373c0__9yHUT border-color--default__373c0__r305k"]//span[@class=" css-bq71j2"]/text()').get(),
            # 'category': response.xpath('//span[@class=" css-bq71j2"]//a/text()').get()
        }