import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class YelpCrawlSpider(CrawlSpider):
    name = 'yelp_crawl'

    start_urls = ["https://www.yelp.ca/search?cflt=fishnchips&find_loc=Toronto%2C+Ontario%2C+CA"]



    le_yelp_details = LinkExtractor(restrict_xpaths='//span[@class=" css-1pxmz4g"]//a')
    le_next = LinkExtractor(restrict_xpaths='//a[@class="next-link navigation-button__09f24__1EzzD css-166la90"]')

    rule_yelp_details = Rule(le_yelp_details, callback='parse_item', follow=True)
    rules = (
        rule_yelp_details,
    )

    rule_next = Rule(le_next, follow=True)
    rules = (
        rule_yelp_details,
        rule_next
    )

    def parse_item(self, response):
        yield {
            'Links':response.xpath('..//@href').get(),
            'Name': response.xpath('//h1[@class="css-11q1g5y"]/text()').get(),
            'Reviews': response.xpath('//*[@id="wrap"]/div[2]/yelp-react-root/div[1]/div[3]/div[1]/div[1]/div/div/div[2]/div[2]/span/text()').get(),
            'Foodtype': response.xpath('//*[@id="wrap"]/div[2]/yelp-react-root/div[1]/div[3]/div[1]/div[1]/div/div/span[3]/span/a/text()').get(),
            'Phone number': response.xpath('//*[@id="wrap"]/div[2]/yelp-react-root/div[1]/div[4]/div/div/div[2]/div/div[2]/div/div/section[1]/div/div[2]/div/div[1]/p[2]/text()').get(),
            'Address': response.xpath('//p[@class=" css-znumc2"]//span/text()').get(),
            'images': response.xpath('//img[@class=" photo-header-media-image__373c0__rKqBU"]/@src').get(),
            'rating': response.xpath('//span[@class=" display--inline__373c0__31SCF margin-l0-5__373c0__1Ju8t border-color--default__373c0__r305k"][1]/text()').get(),
            'Locationhours': response.xpath('// span[@class=" display--inline__373c0__31SCF margin-l1__373c0__9yHUT border-color--default__373c0__r305k"]//span[@class=" css-bq71j2"]/text()').get(),
            'category': response.xpath('//span[@class=" css-bq71j2"]//a/text()').get()
        }



